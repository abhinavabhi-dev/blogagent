# Quillbase – AI writing studio

Vercel (hosting + serverless API) · Supabase (auth + Postgres in the cloud) · Anthropic API (writing).
Credits are enforced on the server, so users can't edit their own balance.

## 1. Supabase (cloud database + login)
1. Create a project at https://supabase.com.
2. SQL Editor → paste and run `supabase/schema.sql`.
3. Project Settings → API: copy the Project URL, `anon` key and `service_role` key.
4. Authentication → URL Configuration: set Site URL to your Vercel URL (add it after step 3 below).

## 2. GitHub
```bash
cd quillbase
git init && git add . && git commit -m "Quillbase v1"
git branch -M main
git remote add origin https://github.com/YOUR-USER/quillbase.git
git push -u origin main
```

## 3. Vercel
1. https://vercel.com/new → import the GitHub repo (framework: Other; no build command; output dir `public`).
2. Add Environment Variables (see `.env.example`):
   `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `ANTHROPIC_API_KEY`, optional `ANTHROPIC_MODEL`.
3. Deploy. Every `git push` to `main` redeploys automatically.
4. Put the deployed URL in Supabase → Authentication → URL Configuration (Site URL + Redirect URLs).

## Local run
```bash
npm i -g vercel && npm install
cp .env.example .env.local   # fill in values
vercel dev
```
Never expose `SUPABASE_SERVICE_ROLE_KEY` or `ANTHROPIC_API_KEY` in front-end code.
