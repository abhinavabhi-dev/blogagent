-- Run this once in Supabase > SQL Editor
create table if not exists profiles (
  user_id uuid primary key references auth.users on delete cascade,
  balance int not null default 10000 check (balance >= 0)
);
create table if not exists documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create table if not exists ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users on delete cascade,
  reason text not null,
  delta int not null,
  created_at timestamptz not null default now()
);
create index if not exists documents_user_idx on documents (user_id, created_at desc);
create index if not exists ledger_user_idx on ledger (user_id, created_at desc);

alter table profiles enable row level security;
alter table documents enable row level security;
alter table ledger enable row level security;

create policy "own profile read" on profiles for select using (auth.uid() = user_id);
create policy "own ledger read" on ledger for select using (auth.uid() = user_id);
create policy "own docs read" on documents for select using (auth.uid() = user_id);
create policy "own docs update" on documents for update using (auth.uid() = user_id);
create policy "own docs delete" on documents for delete using (auth.uid() = user_id);
-- inserts into documents/ledger/profiles happen only server-side (service role)

create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (user_id) values (new.id);
  insert into ledger (user_id, reason, delta) values (new.id, 'Welcome credits', 10000);
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Atomic credit change. Returns new balance, or null if insufficient.
create or replace function adjust_credits(p_user uuid, p_delta int, p_reason text)
returns int language plpgsql security definer set search_path = public as $$
declare nb int;
begin
  update profiles set balance = balance + p_delta
   where user_id = p_user and balance + p_delta >= 0
   returning balance into nb;
  if nb is null then return null; end if;
  insert into ledger (user_id, reason, delta) values (p_user, p_reason, p_delta);
  return nb;
end $$;
revoke all on function adjust_credits(uuid,int,text) from public, anon, authenticated;
grant execute on function adjust_credits(uuid,int,text) to service_role;
