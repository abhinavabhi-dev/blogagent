const { createClient } = require('@supabase/supabase-js');

const VOICES = ['Friendly blog', 'Professional', 'Product page', 'Concise news'];
const WORDS = [400, 800, 1200];

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

  const token = (req.headers.authorization || '').replace(/^Bearer /, '');
  const { data: ud } = await sb.auth.getUser(token);
  const user = ud && ud.user;
  if (!user) return res.status(401).json({ error: 'Please sign in.' });

  const b = req.body || {};
  const brief = String(b.brief || '').trim().slice(0, 2000);
  const voice = VOICES.includes(b.voice) ? b.voice : VOICES[0];
  const words = WORDS.includes(Number(b.words)) ? Number(b.words) : 800;
  const kw = String(b.keywords || '').trim().slice(0, 300) || 'none';
  if (!brief) return res.status(400).json({ error: 'Enter a topic or brief first.' });

  const { data: bal, error: spendErr } = await sb.rpc('adjust_credits', { p_user: user.id, p_delta: -1, p_reason: 'Article generated' });
  if (spendErr) return res.status(500).json({ error: 'Could not reserve credit.' });
  if (bal === null) return res.status(402).json({ error: 'You are out of credits.' });

  try {
    const prompt = `Write a ${words}-word article in the voice: ${voice}.\nTopic: ${brief}\nKeywords to include naturally: ${kw}\nUse a clear title on the first line, then paragraphs with short subheadings. Output plain text only, no markdown symbols.`;
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
        max_tokens: 3000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    if (!r.ok) throw new Error('anthropic ' + r.status);
    const j = await r.json();
    const text = (j.content || []).map(c => c.text || '').join('').trim();
    if (!text) throw new Error('empty');
    const title = text.split('\n')[0].slice(0, 90) || 'Untitled';
    const { data: doc, error } = await sb.from('documents').insert({ user_id: user.id, title, body: text }).select().single();
    if (error) throw error;
    return res.status(200).json({ doc, balance: bal });
  } catch (e) {
    const { data: nb } = await sb.rpc('adjust_credits', { p_user: user.id, p_delta: 1, p_reason: 'Refund: generation failed' });
    return res.status(502).json({ error: 'Generation failed. Your credit was refunded.', balance: nb });
  }
};
